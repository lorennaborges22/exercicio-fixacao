Vamos executar algumas coisas no repositório da Labenu: 

## Exercício 1
Faça um **Fork** deste repositório para copiar para sua conta do GitHub, e, em sua área de trabalho, execute o **clone** do repositório que recebeu o Fork.
Acesse a pasta do repositório clonado.

## Exercício 2
Na raiz do seu repositório local, utilizando o terminal, use o comando git branch para verificar a branch atual. A branch atual deve ser a main.

Crie uma branch chamada ```terminal-e-git``` e, depois, entre nessa branch.

Nesta branch, crie uma pasta chamada minha-bio e, dentro dessa pasta, crie um arquivo chamado minha-bio.txt

## Exercício 3
Nesse arquivo, você deve escrever uma mini biografia sua.

**Entrega**: na próxima aula, aprenderemos como subir esse arquivo no repositório remoto!