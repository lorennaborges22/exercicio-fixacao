# Apenas EU#
Eu me chamo *Lorenna Fernanda Carvalho Borges* tenho 23 anos, sou formada em 
Enfermagem e tenho um cachorro chamado Aquiles(UM FOFO). Gosto muito de escutar 
música e estudar sobre moda, também gosto *muito *de ler sobre os mais divesos 
temas.
 Tenho uma vontade enorme de mudar de vida e espero q  a Labenu seja a 
 ***chavinha*** que vai mudar tudo isso.
  Minha mudança pra tec abalou muitas pessoas, mas o melhor e tudo estou fazendo por mim. Sou a irmã mais velha de 3 irmas então ando bem acompanhada kkk. Isso é um pouquinho do que estou vivendo agora e resume muito uma vida.